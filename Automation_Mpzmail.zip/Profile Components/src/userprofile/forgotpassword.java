package userprofile;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
//import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
//import org.testng.annotations.Test;


public class forgotpassword {
  
	public static void main(String[] args) {
		System.setProperty("webdriver.gecko.driver","D:drivers/geckodriver.exe");
        WebDriver driver = new FirefoxDriver();
//		 System.setProperty("webdriver.chrome.driver", "C:/Users/vikashsharma/emcast/chromedriver.exe");
//		 WebDriver driver=new ChromeDriver();
        driver.manage().window().maximize();
        driver.get("https://dev.web.mpzmail.com/");
//        WebDriverWait wait = new WebDriverWait(driver, 20);
//        wait.until(ExpectedConditions.elementToBeClickable(lastElementToLoad));
         WebElement forgotlink = driver.findElement(By.linkText("Forgotten your Password?"));
		 forgotlink.click();
		 System.out.println(driver.getTitle());
		 WebElement emailaddress=driver.findElement(By.xpath("//*[@name='emailAddress']"));
		 emailaddress.sendKeys("qateamautomation@yopmail.com");
		 WebElement reminderbtn=driver.findElement(By.xpath("//*[@class='button min-shadow full-width']"));
		 reminderbtn.click();
//		 driver.switchTo().alert().getText();
		 String actualUrl="https://dev.web.mpzmail.com/reminder";
		 if (actualUrl == "https://dev.web.mpzmail.com/reminder")
		 {
		      System.out.println("Test case passed");
		    } else {
		      System.out.println("URL'S not found.");
		    }  
		}
	
		}
