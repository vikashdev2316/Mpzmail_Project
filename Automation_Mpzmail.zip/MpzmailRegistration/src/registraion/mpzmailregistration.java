package registraion;

//import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
//import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
//import org.openqa.selenium.support.ui.ExpectedConditions;
//import org.openqa.selenium.support.ui.WebDriverWait;
//import org.junit.Assert;

//import com.sun.tools.javac.util.Assert;

public class mpzmailregistration {

	//private static By lastElementToLoad;

	public static void main(String[] args) throws InterruptedException {
		
		// TODO Auto-generated method stub
		 //System.setProperty("webdriver.chrome.driver", "C:/Users/vikashsharma/Desktop/chromedriver.exe");
		 //WebDriver driver=new ChromeDriver();
		
		// The statement for firefox browser.
		System.setProperty("webdriver.gecko.driver","D:drivers/geckodriver.exe");
        WebDriver driver = new FirefoxDriver();
         driver.manage().window().maximize();
//         WebDriverWait wait = new WebDriverWait(driver, 20);
//         wait.until(ExpectedConditions.elementToBeClickable(lastElementToLoad));
         //driver.manage().timeouts().pageLoadTimeout(15, TimeUnit.SECONDS);
         driver.get("https://web.mpzmail.com/register?welcome=true");
         Thread.sleep(5000);
         //driver.findElement(By.xpath("//*[@class='button button-sml outline primary']")).click();
         Thread.sleep(5000);
		 WebElement companyName = driver.findElement(By.xpath("//*[@name='companyName']"));
		 companyName.sendKeys("TestCompanytutorial1");
		 Thread.sleep(5000);
		 WebElement fullName = driver.findElement(By.xpath("//*[@name='firstName']"));
		 fullName.sendKeys("TestName");
		 Thread.sleep(5000);
		 WebElement lastname = driver.findElement(By.xpath("//*[@name='lastName']"));
		 lastname.sendKeys("TestName");
		 Thread.sleep(5000);
		 WebElement email = driver.findElement(By.xpath("//*[@name='emailAddress']"));
		 email.sendKeys("testemail1@yopmail.com");
		 Thread.sleep(5000);
		 WebElement confirmEmail = driver.findElement(By.xpath("//*[@name='confirmEmail']"));
		 confirmEmail.sendKeys("testemail1@yopmail.com");

		 WebElement password = driver.findElement(By.xpath("//*[@name='password']"));
		 password.sendKeys("Test@12345");
		 
		 WebElement confpassword = driver.findElement(By.xpath("//*[@name='confirmPassword']"));
		 confpassword.sendKeys("Test@12345");

		 WebElement termsOfServices = driver.findElement(By.xpath("//*[@class='checkbox undefined']"));
		 termsOfServices.click();

		 WebElement signUp = driver.findElement(By.xpath("//*[@class='button min-shadow full-width']"));
		 signUp.click();

		 System.out.println("Page title: " + driver.getTitle());

	       String actualUrl="https://web.mpzmail.com/cp/home/";
	       String expectedUrl= driver.getCurrentUrl();
	      
	      if(actualUrl.equalsIgnoreCase(expectedUrl))
	      {
	          System.out.println("Test passed");
	      }
	      else 
	      {
	          System.out.println("We've sent you an email!");
	      }
	      //driver.quit(); 
		
	}

}
