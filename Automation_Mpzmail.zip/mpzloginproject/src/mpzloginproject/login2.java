package mpzloginproject;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

//import org.openqa.selenium.firefox.FirefoxDriver;

public class login2 {
	public static void main(String[] args)  {

		System.setProperty("webdriver.chrome.driver", "C:\\Users\\vikashsharma\\emcast\\android\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://dev.web.mpzmail.com/");
		WebElement button = driver.findElement(By.id("//*[@id=\"root\"]/div/div[1]/div/div[2]/div/div[6]/div/button"));
		//WebElement password=driver.findElement(By.xpath("//*[@id=\"root\"]/div/div[1]/div/div[2]/div/div[4]/div/div/div/input"));
		//WebElement login=driver.findElement(By.className("button no-shadow min-width button-md"));
//		username.sendKeys("dikshachaudhary1@virtualemployee.com");
//		password.sendKeys("Dikshach@12345");
		button.click();
		System.out.println("Button class added susccessfully.");
//		String actualUrl="https://dev.web.mpzmail.com/";
//		String expectedUrl= driver.getCurrentUrl();
//	    Assert.assertEquals(expectedUrl,actualUrl);
		}

	}