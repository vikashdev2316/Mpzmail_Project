package mpzloginproject;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
//import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class Logincase {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		//The statement for google chrome browser
   //		System.setProperty("webdriver.chrome.driver", "D://All Drivers/chromedriver.exe");
		  //WebDriver driver=new ChromeDriver();
        //driver.get("https://google.com");
		
		// The statement for firefox browser.
		System.setProperty("webdriver.gecko.driver","D:drivers/geckodriver.exe");
         WebDriver driver=new FirefoxDriver();
         driver.manage().window().maximize();
         driver.get("https://dev.web.mpzmail.com/");

        WebElement username = new WebDriverWait(driver, 20).until(ExpectedConditions.elementToBeClickable(By.xpath("emailAddress")));
		WebElement password = new WebDriverWait(driver, 20).until(ExpectedConditions.elementToBeClickable(By.name("password")));
		WebElement login = new WebDriverWait(driver, 20).until(ExpectedConditions.elementToBeClickable(By.xpath("//*[@id=\"root\"]/div/div[1]/div/div[2]/div/div[7]/div/button")));
      
      username.sendKeys("dikshachaudhary1@virtualemployee.com");
      password.sendKeys("Dikshach@1234");
      login.click();
      
      System.out.println("Page title: " + driver.getTitle());

       String actualUrl="https://dev.web.mpzmail.com/";
       String expectedUrl= driver.getCurrentUrl();
      
      if(actualUrl.equalsIgnoreCase(expectedUrl))
      {
          System.out.println("Test passed");
      }
      else 
      {
          System.out.println("Test failed");
      }
      //driver.quit(); 

	}
	
}

